Necrosis.Config.Fonts = {
    -- Add fonts with index, name and relative path
    [1] = { Name = "Roboto-Black", Path = "Interface\\Addons\\Necrosis-Classic\\Fonts\\Roboto-Black.ttf" },
    [2] = { Name = "FritzQT", Path = "Fonts\\FRIZQT__.TTF" }
}